import pandas as pd

# Function to convert GFF to BED
def gff_to_bed(gff_file, bed_file):
    """
    Convert a GFF file to BED format.
    """
    with open(gff_file, 'r') as gff, open(bed_file, 'w') as bed:
        for line in gff:
            if line.startswith("#") or not line.strip():
                continue  
            fields = line.strip().split("\t")
            # Skip improperly formatted lines
            if len(fields) < 9:
                continue  
            
            # Extract necessary information
            chrom = fields[0]
            start = int(fields[3]) - 1  
            end = int(fields[4]) 
            strand = fields[6]
            
            # Extract gene ID
            attributes = fields[8]
            gene_id = "unknown"
            for attr in attributes.split(";"):
                if attr.strip().startswith("ID="):
                    gene_id = attr.split("=")[1].strip()
                    break

            bed.write(f"{chrom}\t{start}\t{end}\t{gene_id}\t0\t{strand}\n")

# Function to convert chromosome IDs
def convert_chromosome_ids(input_bed, output_bed):
    """
    Convert chromosome IDs in the BED file to numeric format.
    """
    # Define mapping table
    chrom_map = {
        "NC_024459.2": "1",
        "NC_024460.2": "2",
        "NC_024461.2": "3",
        "NC_024462.2": "4",
        "NC_024463.2": "5",
        "NC_024464.2": "6",
        "NC_024465.2": "7",
        "NC_024466.2": "8",
        "NC_024467.2": "9",
        "NC_024468.2": "10"
    }

    bed_data = pd.read_csv(input_bed, sep="\t", header=None)

    bed_data[0] = bed_data[0].map(chrom_map).fillna(bed_data[0])  

    bed_data.to_csv(output_bed, sep="\t", index=False, header=False)

# Main function
def main():

    gff_file = r"ref_contrast\02_data\01_our_ouput\out_DTA.gff"  # Path to the GFF file
    final_bed_file = r"ref_contrast\02_data\02_bed\01_output\out_DTA.bed"  # Output BED file
    
    print("1: Converting GFF to BED...")
    gff_to_bed(gff_file, final_bed_file)
    print(f"GFF has been converted to BED: {final_bed_file}")
    
    print("2: Standardizing chromosome naming...")
    convert_chromosome_ids(final_bed_file, final_bed_file)
    print(f"Chromosome naming has been standardized: {final_bed_file}")

if __name__ == "__main__":
    main()
