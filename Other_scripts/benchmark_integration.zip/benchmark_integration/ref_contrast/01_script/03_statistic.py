import pandas as pd

def calculate_lengths(intersect_file):
    """
    Calculate the total intersection length and total length of entries in the main file.

    Parameters:
    intersect_file: Path to the intersect output file.

    Returns:
    total_intersection_length: Total length of all valid intersections.
    total_query_length: Total length of all entries in the main file.
    """
    total_intersection_length = 0
    total_query_length = 0
    
    with open(intersect_file, 'r') as f:
        lines = f.readlines()
        i = 0
        while i < len(lines):
            # Process the main file line (odd lines)
            query_fields = lines[i].strip().split()
            query_start = int(query_fields[1])
            query_end = int(query_fields[2])
            query_length = query_end - query_start
            total_query_length += query_length
            
            # Process the second file line (even lines)
            if i + 1 < len(lines):
                subject_fields = lines[i+1].strip().split()
                # Check if there is a valid intersection (not ". -1 -1 . . .")
                if subject_fields[0] != '.':
                    subject_start = int(subject_fields[1])
                    subject_end = int(subject_fields[2])
                    
                    # Calculate intersection length
                    intersection_start = max(query_start, subject_start)
                    intersection_end = min(query_end, subject_end)
                    if intersection_end > intersection_start:
                        intersection_length = intersection_end - intersection_start
                        total_intersection_length += intersection_length
            
            # Move to the next set of data
            i += 2
    
    return total_intersection_length, total_query_length

def calculate_total_length(bed_file):
    """
    Calculate the total length of all annotated entries in a BED file.

    Parameters:
    bed_file: Path to the BED file.

    Returns:
    total_length: Total length of all intervals.
    entry_count: Total number of entries.
    """
    total_length = 0
    entry_count = 0
    
    try:
        with open(bed_file, 'r') as f:
            for line in f:
                # Skip empty lines and comments
                if line.strip() == '' or line.startswith('#'):
                    continue
                
                # Split the line contents
                fields = line.strip().split('\t')
                
                if len(fields) >= 3:
                    try:
                        start = int(fields[1])
                        end = int(fields[2])
                        length = end - start
                        
                        # Only count valid lengths (greater than 0)
                        if length > 0:
                            total_length += length
                            entry_count += 1
                            
                    except ValueError:
                        print(f"Warning: Skipping invalid line: {line.strip()}")
                        continue
                        
    except FileNotFoundError:
        print(f"Error: File not found {bed_file}")
        return 0, 0
    
    return total_length, entry_count

def format_bp(bp):
    """Format base pair count into a human-readable format."""
    if bp >= 1_000_000:
        return f"{bp/1_000_000:.2f} Mb"
    elif bp >= 1_000:
        return f"{bp/1_000:.2f} kb"
    else:
        return f"{bp:.2f} bp"

def process_family_statistics(family, output_file):
    """
    Perform intersection calculations and statistics for a given transposon family and save results to a file.

    Parameters:
    family: Name of the transposon family.
    output_file: Path to the file where results will be saved.
    """
    # Construct file paths
    intersect_file = fr"ref_contrast\02_data\03_intersect\ref3\{family}_refloj.bed"
    bed_file = fr"ref_contrast\02_data\01_our_ouput\out_{family}.bed"
    ref_file = fr"ref_contrast\02_data\02_ref\ref3\ref3_{family}.bed"
    u_file = fr"dref_contrast\02_data\03_intersect\ref3\{family}_ref.bed"

    # Calculate lengths
    intersection_length, query_length = calculate_lengths(intersect_file)
    # Calculate total lengths and entry counts
    total_length, entry_count = calculate_total_length(bed_file)
    total_length2, entry_count2 = calculate_total_length(ref_file)
    total_length3, entry_count3 = calculate_total_length(u_file)

    # Prepare results
    results = []
    results.append(f"\n=== {family} statistics ===")
    results.append("--- Results ---")
    results.append(f"Item count: {entry_count:,}")
    results.append(f"Total result length: {format_bp(total_length)}")
    results.append(f"Average result length: {format_bp(total_length/entry_count)}")
    results.append("--- Reference ---")
    results.append(f"Item count: {entry_count2:,}")
    results.append(f"Total reference length: {format_bp(total_length2)}")
    results.append(f"Average reference length: {format_bp(total_length2/entry_count2)}")
    results.append("--- Intersection ---")
    results.append(f"Total intersection length: {format_bp(intersection_length)}")
    results.append(f"Intersection count: {entry_count3:,}")
    results.append(f"Count ratio: {entry_count3/entry_count:.2%}")
    # Calculate and print intersection ratios
    intersection_ratio = (intersection_length / total_length) if query_length > 0 else 0
    results.append(f"Ratio to results: {intersection_ratio:.2%}")
    results.append(f"Ratio to reference: {intersection_length / total_length2:.2%}")

    # Save results to file
    with open(output_file, 'a') as f:
        for line in results:
            f.write(line + '\n')
    print(f"Statistics for {family} saved to {output_file}.")

if __name__ == "__main__":
    # List of transposon families
    families = ["DTT", "DTA", "DTH", "DTC"]
    output_file = "family_statistics.txt"

    # Clear the file before writing
    with open(output_file, 'w') as f:
        f.write("Transposon Family Statistics\n")

    for family in families:
        process_family_statistics(family, output_file)
