import pandas as pd

def merge_bed_files(bed_files, output_file):
    """
    Merge multiple BED files into a single file while preserving additional columns and
    ensuring intervals are merged based on strand specificity.

    Args:
        bed_files (list of str): List of file paths to BED files.
        output_file (str): Path to the output merged BED file.
    """
    # List to hold dataframes for each BED file
    dfs = []
    
    # Load each BED file into a dataframe
    for file in bed_files:
        df = pd.read_csv(
            file,
            sep='\t',
            header=None,
            names=["chrom", "start", "end", "name", "score", "strand"]
        )
        dfs.append(df)

    # Concatenate all dataframes
    merged_df = pd.concat(dfs, ignore_index=True)

    # Sort the data by chromosome, strand, and start position
    merged_df = merged_df.sort_values(by=["chrom", "strand", "start", "end"])

    # Merge overlapping intervals on the same strand
    merged_bed = []
    current_row = None

    for row in merged_df.itertuples(index=False):
        if current_row is None:
            current_row = row
        elif (
            row.chrom == current_row.chrom and
            row.strand == current_row.strand and
            row.start <= current_row.end
        ):
            # Merge intervals
            current_row = current_row._replace(
                end=max(current_row.end, row.end)
            )
        else:
            # No overlap, add the current interval to the result
            merged_bed.append(current_row)
            current_row = row

    # Add the last interval
    if current_row:
        merged_bed.append(current_row)

    # Convert merged intervals back to a DataFrame
    final_df = pd.DataFrame(
        merged_bed,
        columns=["chrom", "start", "end", "name", "score", "strand"]
    )

    # Save to the output file
    final_df.to_csv(output_file, sep='\t', index=False, header=False)

# Example usage
bed_files = [r"ref_contrast\02_data\02_ref\ref2\ref2_merge.bed", r"ref_contrast\02_data\02_ref\ref1\typeII_merge.bed"]
output_file = r"ref_contrast\02_data\02_ref\ref3\ref3_merge.bed"

merge_bed_files(bed_files, output_file)
