import pandas as pd

def extract_TE_from_bed(bed_file, output_file_prefix, families):
    """
    Extract specific TE families from a BED file and save them to separate files.
    """
    # Read the BED file
    df = pd.read_csv(bed_file, sep="\t", header=None)
    # Add column names, assuming BED format is chrom, start, end, name, score, strand
    df.columns = ['chrom', 'start', 'end', 'name', 'score', 'strand']

    for family in families:
        # Filter rows containing the specific family
        family_TE = df[df['name'].str.contains(family, na=False)]

        # Save the filtered results
        output_file = f"{output_file_prefix}_{family}.bed"
        family_TE.to_csv(output_file, sep="\t", index=False, header=False)
        print(f"Successfully extracted {len(family_TE)} TEs from the {family} family. Results saved in {output_file}.")

# Example usage
if __name__ == "__main__":
    # Uncomment to convert GFF to BED
    # gff_file = r"data\bed\ref3\MaizeB73_TIR.gff3"
    bed_file = r'ref_contrast\02_data\02_ref\ref1\b73_ref.bed'
    # gff_to_bed(gff_file, bed_file)

    output_file_prefix = r'ref_contrast\02_data\02_ref\ref1\b73_ref.bed'
    families = ['DTA', 'DTH', 'DTC', 'DTT']
    extract_TE_from_bed(bed_file, output_file_prefix, families)