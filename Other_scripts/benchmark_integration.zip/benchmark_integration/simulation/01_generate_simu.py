import random
from Bio import SeqIO

def read_fasta_sequences(fasta_file):
    """Read sequences from a FASTA file."""
    sequences = []
    for record in SeqIO.parse(fasta_file, "fasta"):
        sequences.append(str(record.seq))
    return sequences

def generate_sequence(length):
    """Generate a DNA sequence of a specified length and complexity."""
    return ''.join(random.choice(['A', 'T', 'C', 'G']) for _ in range(length))

def generate_reverse_complement(sequence):
    """Generate the reverse complement of a sequence."""
    complement = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
    return ''.join(complement.get(base, 'N') for base in reversed(sequence))

def insert_noise(seq, noise_rate):
    """Insert noise into a sequence."""
    noisy_seq = list(seq)
    for i in range(len(noisy_seq)):
        if random.random() < noise_rate:
            noisy_seq[i] = 'N'
    return ''.join(noisy_seq)

def generate_positive_example(tsd_length, tir_length, min_gap, max_gap, transposase_sequences, noise_rate=0.0):
    """Generate a positive example containing TSD, TIR, and transposase."""
    gap_length1 = random.randint(min_gap, max_gap)
    gap1 = generate_sequence(gap_length1)
    tsd = generate_sequence(tsd_length)
    tir = generate_sequence(tir_length)
    gap_length = random.randint(min_gap, max_gap)
    gap = generate_sequence(gap_length)
    rev_tir = generate_reverse_complement(tir)
    gap_length2 = random.randint(min_gap, max_gap)
    gap2 = generate_sequence(gap_length2)
    # Randomly select a transposase sequence
    transposase = random.choice(transposase_sequences)

    # Insert transposase
    seq = gap1 + tsd + tir + transposase + rev_tir + tsd + gap2
    seq = insert_noise(seq, noise_rate)

    # Calculate the start and end positions of the transposon
    transposon_start = gap_length1
    transposon_end = transposon_start + len(tsd) + len(tir) + len(transposase)

    # Return the sequence and annotation information
    return seq, (0, transposon_start, transposon_end, 'positive')

def generate_negative_example(min_length, max_length, noise_rate=0.0):
    """Generate a random negative example."""
    length = random.randint(min_length, max_length)
    seq = generate_sequence(length)
    seq = insert_noise(seq, noise_rate)
    return seq, ('randomseq')

def generate_negative_example2(min_gap, max_gap, transposase_sequences, noise_rate=0.0):
    """Generate a negative example without TSD and TIR."""
    gap_length1 = random.randint(min_gap, max_gap)
    gap1 = generate_sequence(gap_length1)
    gap_length2 = random.randint(min_gap, max_gap)
    gap2 = generate_sequence(gap_length2)
    transposase = random.choice(transposase_sequences)
    seq = gap1 + transposase + gap2
    seq = insert_noise(seq, noise_rate)
    return seq, ('noTIR')

def generate_negative_example3(tsd_length, tir_length, min_gap, max_gap, min_length, max_length, noise_rate=0.0):
    """Generate a negative example without transposase."""
    length = random.randint(min_length, max_length)
    ran = generate_sequence(length - 1000)
    tsd = generate_sequence(tsd_length)
    tir = generate_sequence(tir_length)
    gap_length1 = random.randint(min_gap, max_gap)
    gap1 = generate_sequence(gap_length1)
    gap_length2 = random.randint(min_gap, max_gap)
    gap2 = generate_sequence(gap_length2)
    rev_tir = generate_reverse_complement(tir)
    seq = gap1 + tsd + tir + ran + rev_tir + tsd + gap2
    seq = insert_noise(seq, noise_rate)    
    return seq, ('no transposase')

def generate_dataset(num_positive, num_negative, tsd_length, tir_length, min_gap, max_gap, 
                    min_neg_length, max_neg_length, transposase_sequences, noise_rate=0.0):
    """Generate a dataset containing positive and randomly selected negative examples."""
    dataset = []
    annotations = []
    
    # Generate positive examples
    for i in range(num_positive):
        seq, annotation = generate_positive_example(tsd_length, tir_length, min_gap, max_gap, 
                                                 transposase_sequences, noise_rate)
        dataset.append((seq, annotation, "positive"))
        if annotation:
            annotations.append(annotation)
    
    # Generate negative examples (randomly select types)
    for i in range(num_negative):
        # Randomly select the type of negative example
        negative_type = random.choice(['random', 'noTIR', 'noTransposase'])
        
        if negative_type == 'random':
            seq, annotation = generate_negative_example(min_neg_length, max_neg_length, noise_rate)
            dataset.append((seq, annotation, "negative_random"))
        
        elif negative_type == 'noTIR':
            seq, annotation = generate_negative_example2(min_gap, max_gap, transposase_sequences, noise_rate)
            dataset.append((seq, annotation, "negative_noTIR"))
        
        else:  # noTransposase
            seq, annotation = generate_negative_example3(tsd_length, tir_length, min_gap, max_gap,
                                                      min_neg_length, max_neg_length, noise_rate)
            dataset.append((seq, annotation, "negative_noTransposase"))
    return dataset, annotations

def save_annotations_to_bed(annotations, bed_file):
    """Save annotation information to a BED file."""
    with open(bed_file, 'w') as f:
        for i, annotation in enumerate(annotations):
            seq_start, transposon_start, transposon_end, type = annotation
            f.write(f"seq{i}\t{ transposon_start}\t{transposon_end}\ttransposase\n")

# Example usage
def save_results_to_file(dataset, output_file):
    """Save results to a file."""
    with open(output_file, 'w') as f:
        for i, (seq, annotation, seq_type) in enumerate(dataset):
            f.write(f">Sequence_{i+1}_{seq_type}\n")
            f.write(f"Type: {seq_type}\n")
            f.write(f"Annotation: {annotation}\n")
            f.write(f"Sequence: {seq}\n")
            f.write("-" * 50 + "\n")

def convert_to_fasta(input_file, output_file):
    """Convert a specially formatted txt file to FASTA format."""
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        header = ""
        sequence = ""
        
        for line in infile:
            line = line.strip()
            
            # Skip separator lines
            if line.startswith('-'):
                if header and sequence:
                    # Write the collected sequence
                    outfile.write(f"{header}\n{sequence}\n")
                header = ""
                sequence = ""
                continue
                
            # Process sequence name lines
            if line.startswith('>'):
                header = line
            # Process sequence lines    
            elif line.startswith('Sequence:'):
                sequence = line.replace('Sequence:', '').strip()
            
        # Write the last sequence
        if header and sequence:
            outfile.write(f"{header}\n{sequence}\n")

# Example usage
def main():
    fasta_file = r"simulation\TE_mRNA_seq.fa"
    output_file = r"simulation\simu_set\simu_sequences.00.txt"
    output_bed = r"simulation\simu_set\func_TE.00.bed"
    transposase_sequences = read_fasta_sequences(fasta_file)

    output_fa = r"simulation\simu_set\simulation100.00.fasta"  # Output file path
    
    # generate 100 simulation seq, with 50 positive,and 50 negative
    dataset, annotations = generate_dataset(
        num_positive=50,
        num_negative=50,  # Total number of negative examples
        tsd_length=8,
        tir_length=5,
        min_gap=500,
        max_gap=2000,
        min_neg_length=2000,
        max_neg_length=7000,
        transposase_sequences=transposase_sequences,
        noise_rate=0.01
    )

    # Save results to file
    save_results_to_file(dataset, output_file)
    save_annotations_to_bed(annotations,output_bed)
    convert_to_fasta(output_file, output_fa)
    # Print statistics
    sequence_types = {}
    for _, _, seq_type in dataset:
        sequence_types[seq_type] = sequence_types.get(seq_type, 0) + 1
    
    print("dataset_statistic")
    for seq_type, count in sequence_types.items():
        print(f"{seq_type}: {count} sequences")

if __name__ == "__main__":
    main()
